# frozen_string_literal: true

# Explicit-only byte-format and host tests. No gems, foreign core, or native
# extension is loaded by these tests.
require 'tmpdir'
require 'fileutils'
require_relative '../lib/jed_native'
require_relative '../lib/jed_native/storage'

module RubyStorageTest
  FIXTURES = File.expand_path('../../../spec/fileformat/fixtures', __dir__)
  REJECTED = %w[cow_invalid_free_list.jed malformed_decimal_group.jed malformed_fk_type.jed
                malformed_interior_cycle.jed malformed_leaf_directory.jed malformed_missing_type.jed
                malformed_overflow_cycle.jed malformed_row_count.jed malformed_wrong_tree_leaf.jed].freeze

  def self.assert(value, message = 'assertion failed')
    raise message unless value
  end

  def self.error(code)
    yield
  rescue JedNative::Error => exception
    assert(exception.sqlstate == code, "expected #{code}, got #{exception.sqlstate}: #{exception.message}")
  else
    raise "expected #{code}"
  end

  def self.snapshot(rows)
    codec = JedNative::FileFormat.new
    { tables: [{ name: 't', columns: [codec.col('id', 'i32', pk: true), codec.col('v', 'text')], rows: rows }] }
  end

  def self.golden_decode
    codec = JedNative::FileFormat.new
    accepted = 0
    Dir[File.join(FIXTURES, '*.jed')].sort.each do |path|
      name = File.basename(path)
      begin
        codec.decode_image(File.binread(path))
        raise "accepted corrupt #{name}" if REJECTED.include?(name)
        accepted += 1
      rescue StandardError => exception
        raise "#{name}: #{exception.message}" unless REJECTED.include?(name)
      end
    end
    assert(accepted == 97, "expected 97 readable fixtures, got #{accepted}")
  end

  def self.golden_encode
    codec = JedNative::FileFormat.new
    count = 0
    Dir[File.join(FIXTURES, '*_table.jed')].sort.each do |path|
      next if File.basename(path).match?(/collation|expr_index|partial_index|timezone_index|hostfunc_index|exclude_followon/)

      expected = File.binread(path)
      state = codec.decode_image(expected)
      actual = codec.build_image(state[:types], state[:sequences], state[:tables], 256,
                                 state[:collations], views: state[:views])
      assert(expected == actual, "encoded bytes differ from #{File.basename(path)}")
      count += 1
    end
    assert(count == 65, "expected 65 byte comparisons, got #{count}")
  end

  def self.durable_recovery
    Dir.mktmpdir('jed-ruby-storage') do |dir|
      path = File.join(dir, 'state.jed')
      store = JedNative::Storage.new(path: path, create: true, page_size: 256)
      store.commit(snapshot([[1, 'old']]))
      old_meta = store.meta.dup
      rows = 250.times.map { |index| [index, "payload-#{index}"] }
      store.commit(snapshot(rows))
      newest_meta = store.meta.dup
      store.close
      bytes = File.binread(path)
      offset = newest_meta[:slot] * 256
      assert(bytes.byteslice(offset + 44, 4).unpack1('N').positive?, 'overflow manifest was not exercised')
      store = JedNative::Storage.new(path: path)
      assert(store.load[:tables].first[:rows] == rows)
      store.close
      # The new root is checksummed in the manifest; damaging it must fall back
      # to the preceding complete generation without replaying any body pages.
      File.open(path, 'r+b') do |file|
        where = newest_meta[:root_page] * 256 + 16
        byte = file.pread(1, where).getbyte(0)
        file.pwrite([byte ^ 1].pack('C'), where)
        file.fsync
      end
      store = JedNative::Storage.new(path: path)
      assert(store.meta[:txid] == old_meta[:txid], 'did not recover the previous generation')
      assert(store.load[:tables].first[:rows] == [[1, 'old']])
      store.commit(snapshot([[2, 'after recovery']]))
      store.close
      store = JedNative::Storage.new(path: path)
      assert(store.load[:tables].first[:rows] == [[2, 'after recovery']])
      store.close
    end
  end

  def self.locking
    Dir.mktmpdir('jed-ruby-lock') do |dir|
      path = File.join(dir, 'locked.jed')
      store = JedNative::Storage.new(path: path, create: true)
      error('55006') { JedNative::Storage.new(path: path, file_lock_timeout_ms: 0) }
      # A separate OS descriptor must see the same protocol-v2 ownership lock.
      File.open("#{path}.lock/presence", 'r+b') do |presence|
        assert(!presence.flock(File::LOCK_EX | File::LOCK_NB), 'presence lock was not held')
      end
      store.close
      File.link(path, File.join(dir, 'alias.jed'))
      error('55006') { JedNative::Storage.new(path: path) }
    end
  end

  def self.storage_limit_and_serialization
    Dir.mktmpdir('jed-ruby-limit') do |dir|
      path = File.join(dir, 'bounded.jed')
      store = JedNative::Storage.new(path: path, create: true, page_size: 256, max_storage_bytes: 256)
      error('54P06') { store.commit(snapshot([[1, 'more than just a catalog page']])) }
      assert(store.meta[:txid] == 1)
      error('54000') { store.commit(tables: [{ name: 'bad', columns: [{ name: 'x', type: 'unavailable' }], rows: [[1]] }]) }
      assert(store.load[:tables].empty?, 'serialization error poisoned or altered the committed snapshot')
      store.close
    end
  end

  def self.io_failure
    Dir.mktmpdir('jed-ruby-failure') do |dir|
      path = File.join(dir, 'failed.jed')
      store = JedNative::Storage.new(path: path, create: true, page_size: 256)
      file = store.instance_variable_get(:@file)
      def file.pwrite(*) = raise(IOError, 'injected write failure')
      error('58030') { store.commit(snapshot([[1, 'new']])) }
      error('58030') { store.load }
      error('58030') { store.close }
      reopened = JedNative::Storage.new(path: path)
      assert(reopened.load[:tables].empty?)
      reopened.close
    end
  end

  def self.sql_reopen
    Dir.mktmpdir('jed-ruby-sql') do |dir|
      path = File.join(dir, 'sql.jed')
      db = JedNative.create(path, page_size: 256)
      db.execute("create table t (id i32 primary key, v text default 'hello', n decimal(9,2))")
      db.execute('insert into t (id,n) values (1,12.50)')
      db.execute('create index t_v on t (v desc)')
      db.execute('create view visible as select id,v from t')
      txid = db.engine.instance_variable_get(:@storage).meta[:txid]
      db.execute('begin')
      db.execute('commit')
      assert(db.engine.instance_variable_get(:@storage).meta[:txid] == txid, 'empty transaction wrote main')
      db.close
      db = JedNative.open(path)
      assert(db.query('select id,v,n from t').rows.map { |row| row.map(&:to_s) } == [['1', 'hello', '12.50']])
      assert(db.query('select * from visible').rows == [[1, 'hello']])
      db.execute('insert into t (id) values (2)')
      db.close
      db = JedNative.open(path)
      assert(db.query('select id,v from t order by id').rows == [[1, 'hello'], [2, 'hello']])
      db.close
    end
  end

  def self.run
    tests = %i[golden_decode golden_encode durable_recovery locking storage_limit_and_serialization io_failure sql_reopen]
    tests.each do |name|
      public_send(name)
      puts "ruby-native storage: #{name} passed"
    end
    puts "ruby-native storage: #{tests.length} tests passed (106 shared images, 65 byte-exact encodes)"
  end
end

RubyStorageTest.run
