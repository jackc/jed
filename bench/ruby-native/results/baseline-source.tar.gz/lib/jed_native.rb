# frozen_string_literal: true

require_relative 'jed_native/error'
require_relative 'jed_native/types'
require_relative 'jed_native/functions'
require_relative 'jed_native/parser'
require_relative 'jed_native/result'
require_relative 'jed_native/engine'
require_relative 'jed_native/expressions'
require_relative 'jed_native/windows'
require_relative 'jed_native/aggregates'
require_relative 'jed_native/schema'

module JedNative
  VERSION = '0.0.0.experimental'

  class Statement
    attr_reader :ast
    def initialize(sql)
      statements = Parser.new(sql).parse
      raise Error.new('42601', 'expected one SQL statement') unless statements.length == 1
      @ast = statements.first
    end
  end

  class Database
    attr_reader :engine

    def initialize(**options)
      @engine = Engine.new(**options)
    end

    def query(sql, *params) = query_prepared(prepare(sql), *params)
    def execute(sql, *params) = query(sql, *params)
    def prepare(sql) = Statement.new(sql)
    def query_prepared(statement, *params) = @engine.run(statement.ast, params)
    alias execute_prepared query_prepared

    def execute_script(sql)
      statements = Parser.new(sql).parse
      if statements.any? { |s| %i[begin commit rollback savepoint release rollback_to].include?(s[:kind]) }
        raise Error.new('0A000', 'transaction control in execute_script')
      end
      raise Error.new('25001', 'execute_script inside a transaction is not implemented') if @engine.transaction_open?
      execute('BEGIN')
      begin
        results = statements.map { |statement| @engine.run(statement) }
        execute('COMMIT')
        results
      rescue StandardError
        execute('ROLLBACK')
        raise
      end
    end

    def transaction
      execute('BEGIN')
      value = yield self
      execute('COMMIT')
      value
    rescue Exception
      execute('ROLLBACK')
      raise
    end

    def close = @engine.close
    def max_cost=(value)
      @engine.max_cost = value
    end
  end

  def self.memory(**options)
    db = Database.new(**options)
    return db unless block_given?
    begin
      yield db
    ensure
      db.close
    end
  end

  def self.create(path, **options, &block) = file_database(path, true, options, &block)
  def self.open(path, **options, &block) = file_database(path, false, options, &block)

  def self.file_database(path, create, options)
    require_relative 'jed_native/persistence'
    db = Database.new
    db.engine.attach_storage(path: path, create: create, **options)
    return db unless block_given?
    begin
      yield db
    ensure
      db.close
    end
  end
end
