# frozen_string_literal: true

module JedNative
  class Row < Array
    def initialize(values, names)
      super(values)
      @names = names
    end

    def [](key, *rest)
      return super if key.is_a?(Integer) || key.is_a?(Range)
      index = @names.index(key.to_s)
      index ? super(index) : nil
    end

    def to_h = @names.zip(self).to_h
  end

  class Result
    include Enumerable
    attr_reader :columns, :column_types, :rows, :cost, :rows_affected
    alias column_names columns

    def initialize(columns: [], column_types: [], rows: [], cost: 0, rows_affected: nil)
      @columns, @column_types, @rows = columns, column_types, rows
      @cost, @rows_affected = cost, rows_affected
    end

    def each
      return enum_for(:each) unless block_given?
      @rows.each { |values| yield Row.new(values, @columns) }
      self
    end

    def close = nil
    def empty? = @rows.empty?
    def size = @rows.size
  end
end
