# frozen_string_literal: true

require_relative "storage"
require_relative "sql_render"

module JedNative
  # Converts idiomatic engine values/catalogs to the language-neutral file
  # representation. The file never contains Ruby object dumps or Ruby source.
  module Persistence
    FOREIGN_ACTIONS = %i[no_action restrict cascade set_null set_default].freeze

    def attach_storage(storage = nil, **options)
      storage ||= Storage.new(**options)
      @storage = storage
      import_storage(storage.load)
      @persisted_snapshot = storage_signature(export_storage)
      self
    rescue StandardError
      storage.close
      @storage = nil
      raise
    end

    def persist
      if @storage
        state = export_storage
        signature = storage_signature(state)
        unless signature == @persisted_snapshot
          @storage.commit(state)
          @persisted_snapshot = signature
        end
      end
      @dirty = false
    end

    def to_image
      state = export_storage
      codec = FileFormat.new
      codec.build_image(state[:types], state[:sequences], state[:tables],
                        @storage&.page_size || 8192, state[:collations], views: state[:views])
    end

    def close
      @storage&.close
    ensure
      super
    end

    def export_storage
      {
        tables: @tables.values.reject { |table| table[:temporary] }.map { |table| export_table(table) },
        types: @types.map { |name, fields| { name: name, fields: fields.map { |field| export_column(field, composite: true) } } },
        sequences: @sequences.map do |name, sequence|
          { name: name, increment: sequence[:increment], min_value: sequence[:min_value] || 1,
            max_value: sequence[:max_value] || ((1 << 63) - 1), start: sequence[:start] || 1,
            cache: sequence[:cache] || 1, cycle: !!sequence[:cycle], last_value: sequence[:value],
            is_called: sequence[:called], owned_by: sequence[:owned_by] }
        end,
        collations: [],
        views: @views.map { |name, view| export_view(name, view) }
      }
    end

    private

    def storage_signature(value)
      case value
      when Hash
        value.reject { |key, _| %i[evaluate where].include?(key) }.transform_values { |item| storage_signature(item) }
      when Array then value.map { |item| storage_signature(item) }
      else value
      end
    end

    def export_column(column, composite: false)
      type = column[:type]
      modifier = column[:type_mod] || column[:typmod]
      modifier = { precision: modifier[0], scale: modifier[1] } if modifier.is_a?(Array)
      result = { name: column[:name], type: type, pk: !!column[:primary_key],
                 not_null: column[:nullable] == false, precision: nil, scale: nil, varchar_len: nil,
                 default: :none, default_expr: nil, identity: nil, collation: nil, temporal: nil }
      if type == 'decimal'
        result[:precision], result[:scale] = modifier&.values_at(:precision, :scale)
      elsif type == 'text'
        result[:varchar_len] = modifier&.dig(:precision)
      elsif %w[timestamp timestamptz interval].include?(type) && modifier
        result[:temporal] = { precision: modifier[:precision], fields: modifier[:fields] || 0 }
      end
      if column[:collation] && column[:collation] != 'C'
        raise Error.new('0A000', 'persisting non-C collations is not implemented in the Ruby experiment')
      end
      if column[:default]
        if type.end_with?('[]') || FileFormat::RANGE_ELEM.key?(type)
          raise Error.new('0A000', 'container column defaults have no supported file representation')
        end
        result[:default_expr] = SQLRender.expression(column[:default])
      end
      identity = column[:identity]
      result[:identity] = identity.is_a?(Hash) ? identity[:mode] : identity if identity
      result.delete(:pk) if composite
      result
    end

    def export_table(table)
      columns = table[:columns].map { |column| export_column(column) }
      pk = table[:constraints].find { |constraint| constraint[:kind] == :primary_key }
      pk_order = pk ? pk[:columns].map { |name| column_ordinal(table, name) } : []
      checks, indexes, fks = [], table[:indexes].map { |index| export_index(table, index) }, []
      table[:constraints].each_with_index do |constraint, position|
        case constraint[:kind]
        when :check
          name = constraint[:name] || "#{table[:name]}_check#{position.zero? ? '' : position}"
          checks << { name: name, expr: SQLRender.expression(constraint[:expr]), host_deps: [] }
        when :unique
          name = constraint[:name] || "#{table[:name]}_#{constraint[:columns].join('_')}_key"
          unless indexes.any? { |index| index[:name] == name }
            indexes << { name: name, cols: constraint[:columns].map { |column| column_ordinal(table, column) }, unique: true, kind: 'btree' }
          end
        when :foreign_key
          parent = table(constraint[:table] || constraint[:ref_table])
          remote = constraint[:ref_columns] || constraint[:reference_columns]
          remote ||= parent[:constraints].find { |entry| entry[:kind] == :primary_key }&.dig(:columns)
          raise Error.new('42830', 'foreign key has no referenced key') unless remote

          actions = FOREIGN_ACTIONS.index(constraint[:on_delete] || :no_action) || 0
          actions |= (FOREIGN_ACTIONS.index(constraint[:on_update] || :no_action) || 0) << 3
          actions |= 64 if constraint[:match] == :full
          fks << { name: constraint[:name] || "#{table[:name]}_#{constraint[:columns].join('_')}_fkey",
                   local: constraint[:columns].map { |column| column_ordinal(table, column) },
                   ref_table: parent[:name], ref: remote.map { |column| column_ordinal(parent, column) }, actions: actions }
        when :exclude
          raise Error.new('0A000', 'persisting exclusion constraints is not implemented in the Ruby experiment')
        end
      end
      rows = table[:rows].map do |row|
        row.each_with_index.map { |value, index| storage_value(columns[index][:type], value) }
      end
      result = { name: table[:name], columns: columns, rows: rows, pk_order: pk_order,
                 checks: checks.sort_by { |check| check[:name].b }, indexes: indexes.sort_by { |index| index[:name].b },
                 fks: fks.sort_by { |fk| fk[:name].b }, exclusions: [] }
      if pk_order.empty? && table[:rowids]
        codec = FileFormat.new
        result[:storage_keys] = table[:rowids].map { |rowid| codec.encode_int(8, rowid) }
      end
      if table[:storage_statistics]
        stale = table[:rows] != table[:storage_rows]
        result[:statistics] = table[:storage_statistics].map { |item| stale ? item.merge(stale: true) : item }
      end
      result
    end

    def column_ordinal(table, name)
      table[:columns].index { |column| column[:name] == name } || raise(Error.new('42703', "unknown column #{name}"))
    end

    def export_index(table, index)
      elements = index[:elements] || (index[:columns] || []).map { |name| { expr: { kind: :column, name: name } } }
      scope = table_columns(table)
      cols = elements.map do |element|
        node = element[:expr]
        if node[:kind] == :column
          column_ordinal(table, node[:name])
        else
          reject_stateful_index(node)
          resolved = compile(node, scope)
          { expr: SQLRender.expression(node), type: resolved.type,
            evaluate: ->(row) { unmetered_storage_evaluate(resolved, table, row, resolved.type) } }
        end
      end
      orders = elements.map do |element|
        desc = element[:direction] == :desc
        first = element[:nulls] ? element[:nulls] == :first : desc
        FileFormat::ORDER_SYMBOLS.key([desc, first])
      end
      result = { name: index[:name], cols: cols, unique: !!index[:unique], kind: index[:method] || 'btree', orders: orders }
      if index[:where]
        reject_stateful_index(index[:where])
        predicate = compile(index[:where], scope)
        result[:predicate] = SQLRender.expression(index[:where])
        result[:where] = ->(row) { unmetered_storage_evaluate(predicate, table, row, 'boolean') == true }
      end
      result
    end

    def reject_stateful_index(node)
      return unless node.is_a?(Hash)

      if node[:kind] == :call && %w[nextval currval setval lastval now clock_timestamp current_date current_time localtimestamp uuidv4 uuidv7 random].include?(node[:name])
        raise Error.new('42P17', 'index expressions must be immutable')
      end
      node.each_value do |value|
        value.is_a?(Array) ? value.each { |item| reject_stateful_index(item) } : reject_stateful_index(value)
      end
    end

    def unmetered_storage_evaluate(expression, table, stored_row, type)
      cost, scalar_bytes = @cost, @scalar_bytes
      row = stored_row.each_with_index.map { |value, i| from_storage_value(table[:columns][i][:type], value) }
      storage_value(type, evaluate(expression, row))
    ensure
      @cost, @scalar_bytes = cost, scalar_bytes
    end

    def storage_value(type, value)
      return nil if value.nil?
      if @types.key?(type)
        return @types[type].each_with_index.map { |field, i| storage_value(field[:type], value[i]) }
      end
      Types.storage_value(type, value)
    end

    def from_storage_value(type, value)
      return nil if value.nil?
      if @types.key?(type)
        return @types[type].each_with_index.map { |field, i| from_storage_value(field[:type], value[i]) }
      end
      Types.from_storage_value(type, value)
    end

    def import_storage(state)
      if !state[:collations].to_a.empty?
        raise Error.new('0A000', 'non-C collation catalogs are not implemented in the Ruby experiment')
      end
      @types = state[:types].to_h do |type|
        [type[:name], type[:fields].map { |field| import_column(field) }]
      end
      @tables = state[:tables].to_h do |stored|
        columns = stored[:columns].map { |column| import_column(column) }
        constraints = []
        unless stored[:pk].empty?
          constraints << { kind: :primary_key, columns: stored[:pk].map { |index| columns[index][:name] } }
        end
        stored[:checks].each do |check|
          raise Error.new('XX002', 'CHECK requires unavailable host functions') unless check[:host_deps].to_a.empty?

          constraints << { kind: :check, name: check[:name], expr: Parser.new(check[:expr]).parse_expression }
        end
        stored[:fks].each do |fk|
          parent = state[:tables].find { |candidate| candidate[:name] == fk[:ref_table] }
          constraints << { kind: :foreign_key, name: fk[:name], columns: fk[:local].map { |i| columns[i][:name] },
                           table: fk[:ref_table], ref_columns: fk[:ref].map { |i| parent[:columns][i][:name] },
                           on_delete: FOREIGN_ACTIONS[fk[:actions] & 7], on_update: FOREIGN_ACTIONS[(fk[:actions] >> 3) & 7],
                           match: fk[:actions] & 64 == 64 ? :full : :simple }
        end
        unless stored[:exclusions].empty?
          raise Error.new('0A000', 'exclusion constraints are not implemented in the Ruby experiment')
        end
        indexes = stored[:indexes].map { |index| import_index(stored, index) }
        indexes.each do |index|
          next unless index[:unique] && !index[:where] && index[:elements].all? { |element| element[:expr][:kind] == :column }

          constraints << { kind: :unique, name: index[:name], columns: index[:columns] }
        end
        rows = stored[:rows].map { |row| row.each_with_index.map { |value, i| from_storage_value(columns[i][:type], value) } }
        rowids = if stored[:pk].empty?
                   codec = FileFormat.new
                   stored[:storage_keys].map { |key| codec.decode_int(8, key) }
                 else
                   (0...rows.length).to_a
                 end
        [stored[:name], { name: stored[:name], columns: columns, constraints: constraints, indexes: indexes,
                         rows: rows, rowids: rowids, next_rowid: (rowids.max || -1) + 1, temporary: false,
                         storage_rows: rows, storage_statistics: stored[:statistics] }]
      end
      @sequences = state[:sequences].to_h do |sequence|
        [sequence[:name], sequence.merge(value: sequence[:last_value], called: sequence[:is_called])]
      end
      @views = state[:views].to_h do |view|
        [view[:name], { kind: :create_view, name: view[:name], columns: view[:columns],
                       query: Parser.new(view[:definition]).parse.first, storage_view: view }]
      end
    end

    def import_column(column)
      modifier = if column[:precision]
                   { precision: column[:precision], scale: column[:scale] }
                 elsif column[:varchar_len]
                   { precision: column[:varchar_len] }
                 elsif column[:temporal]
                   column[:temporal]
                 end
      default = if column[:default_expr]
                  Parser.new(column[:default_expr]).parse_expression
                elsif column.key?(:default) && column[:default] != :none
                  { kind: :literal, type: column[:type], value: from_storage_value(column[:type], column[:default]) }
                end
      { name: column[:name], type: column[:type], nullable: !column[:not_null], primary_key: !!column[:pk],
        type_mod: modifier, default: default, identity: column[:identity], collation: column[:collation], checks: [] }
    end

    def import_index(table, index)
      raise Error.new('XX002', 'index requires unavailable host functions') unless index[:host_deps].to_a.empty?
      raise Error.new('XX002', 'index requires unavailable pinned timezone data') if index[:timezone_deps]

      elements = index[:cols].each_with_index.map do |column, position|
        expression = column.is_a?(Hash) ? Parser.new(column[:expr]).parse_expression : { kind: :column, name: table[:columns][column][:name] }
        desc, first = FileFormat::ORDER_SYMBOLS.fetch(index[:orders]&.at(position) || :asc)
        { expr: expression, direction: desc ? :desc : :asc, nulls: first ? :first : :last }
      end
      { kind: :create_index, name: index[:name], table: table[:name], method: index[:kind], unique: index[:unique],
        elements: elements, columns: elements.map { |element| element[:expr][:name] },
        where: index[:predicate] ? Parser.new(index[:predicate]).parse_expression : nil }
    end

    def export_view(name, view)
      return view[:storage_view] if view[:storage_view]

      columns = view[:columns] || storage_query_columns(view[:query]).map { |column| column[:name] }
      { name: name, columns: columns, definition: SQLRender.query(view[:query]),
        deps: storage_view_dependencies(view[:query]), check_option: 0, defaults: {} }
    end

    def storage_query_columns(query)
      return storage_query_columns(query[:left]) if query[:kind] == :set_operation
      if query[:kind] == :values
        return query[:rows].first.each_with_index.map { |node, index| { name: "column#{index + 1}", type: compile(node, []).type } }
      end
      sources = (query[:from] || []) + (query[:joins] || []).map { |join| join[:relation] }
      scope = sources.flat_map do |source|
        if source[:kind] == :table
          if @tables[source[:name]]
            table_columns(@tables[source[:name]], source[:alias] || source[:name])
          elsif @views[source[:name]]
            storage_query_columns(@views[source[:name]][:query]).map { |column| column.merge(table: source[:alias] || source[:name]) }
          else
            raise Error.new('0A000', 'persisting this view source is not implemented')
          end
        elsif source[:kind] == :subquery
          storage_query_columns(source[:query]).map { |column| column.merge(table: source[:alias]) }
        else
          raise Error.new('0A000', 'persisting this view source is not implemented')
        end
      end
      expand_stars(query[:columns], scope).map do |projection|
        { name: projection[:alias] || expression_name(projection[:expr]), type: compile(projection[:expr], scope).type }
      end
    end

    def storage_view_dependencies(query)
      dependencies = {}
      walk = lambda do |node|
        return unless node.is_a?(Hash)
        if node[:kind] == :table
          name = node[:name]
          if @tables[name]
            dependencies[[name, 0]] = { name: name, kind: 0, columns: @tables[name][:columns].map { |column| column[:name] }.sort }
          elsif @views[name]
            dependencies[[name, 1]] = { name: name, kind: 1, columns: [] }
          end
        elsif node[:kind] == :call && %w[nextval currval setval].include?(node[:name]) && node[:args]&.first&.dig(:kind) == :literal
          name = node[:args].first[:value]
          dependencies[[name, 2]] = { name: name, kind: 2, columns: [] }
        elsif node[:kind] == :cast && @types.key?(node[:type])
          dependencies[[node[:type], 3]] = { name: node[:type], kind: 3, columns: [] }
        end
        node.each_value { |value| value.is_a?(Array) ? value.each { |item| walk.call(item) } : walk.call(value) }
      end
      walk.call(query)
      dependencies.values.sort_by { |dependency| [dependency[:name].b, dependency[:kind]] }
    end
  end

  Engine.prepend(Persistence)
end
