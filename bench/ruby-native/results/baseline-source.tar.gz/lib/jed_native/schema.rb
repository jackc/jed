# frozen_string_literal: true

module JedNative
  module SchemaChanges
    def dispatch(stmt)
      case stmt[:kind]
      when :alter_table then alter_table(stmt)
      else super
      end
    end

    def alter_table(stmt)
      return Result.new if stmt[:if_exists] && !@tables.key?(stmt[:name])
      original = table(stmt[:name])
      t = original.merge(columns: original[:columns].map(&:dup), constraints: original[:constraints].map(&:dup), rows: original[:rows].map(&:dup))
      case stmt[:action]
      when :rename
        raise Error.new('42P07', 'relation already exists') if @tables.key?(stmt[:new_name])
        @tables.delete(t[:name])
        t[:name] = stmt[:new_name]
      when :rename_column
        index = t[:columns].index { |c| c[:name] == stmt[:column] }
        raise Error.new('42703', 'column does not exist') unless index
        raise Error.new('42701', 'column already exists') if t[:columns].any? { |c| c[:name] == stmt[:new_name] }
        t[:columns][index][:name] = stmt[:new_name]
        t[:constraints].each { |c| c[:columns] = c[:columns].map { |n| n == stmt[:column] ? stmt[:new_name] : n } if c[:columns] }
      when :rename_constraint
        constraint = t[:constraints].find { |c| c[:name] == stmt[:column] }
        raise Error.new('42704', 'constraint does not exist') unless constraint
        constraint[:name] = stmt[:new_name]
      else
        (stmt[:actions] || []).each do |action|
          case action[:kind]
          when :add_column
            column = action[:column].dup
            if t[:columns].any? { |c| c[:name] == column[:name] }
              next if action[:if_not_exists]
              raise Error.new('42701', 'duplicate column')
            end
            column[:type] = Types.normalize(column[:type])
            value = column[:default] ? evaluate(compile(column[:default], []), []) : nil
            t[:rows].each { |row| row << assign(value, column) }
            t[:columns] << column
          when :drop_column
            index = t[:columns].index { |c| c[:name] == action[:column] }
            unless index
              next if action[:if_exists]
              raise Error.new('42703', 'column does not exist')
            end
            t[:columns].delete_at(index)
            t[:rows].each { |row| row.delete_at(index) }
            t[:constraints].reject! { |c| c[:columns]&.include?(action[:column]) }
          when :add_constraint
            constraint = action[:constraint]
            raise Error.new('42710', 'duplicate constraint') if constraint[:name] && t[:constraints].any? { |c| c[:name] == constraint[:name] }
            raise Error.new('42P16', 'multiple primary keys') if constraint[:kind] == :primary_key && t[:constraints].any? { |c| c[:kind] == :primary_key }
            t[:constraints] << constraint
          when :drop_constraint, :drop_primary_key
            found = t[:constraints].find { |c| action[:kind] == :drop_primary_key ? c[:kind] == :primary_key : c[:name] == action[:name] }
            raise Error.new('42704', 'constraint does not exist') unless found || action[:if_exists]
            t[:constraints].delete(found)
          when :set_default, :drop_default, :set_not_null, :drop_not_null, :set_type
            index = t[:columns].index { |c| c[:name] == action[:column] }
            raise Error.new('42703', 'column does not exist') unless index
            column = t[:columns][index]
            case action[:kind]
            when :set_default
              assign(evaluate(compile(action[:expr], []), []), column)
              column[:default] = action[:expr]
            when :drop_default then column.delete(:default)
            when :set_not_null
              raise Error.new('23502', 'NULL in column') if t[:rows].any? { |r| r[index].nil? }
              column[:nullable] = false
            when :drop_not_null
              raise Error.new('42P16', 'primary key cannot be nullable') if t[:constraints].any? { |c| c[:kind] == :primary_key && c[:columns].include?(column[:name]) }
              column[:nullable] = true
            when :set_type
              expr = action[:using] ? compile(action[:using], table_columns(t)) : nil
              column[:type] = Types.normalize(action[:type])
              column[:type_mod] = action[:type_mod]
              t[:rows].each { |row| row[index] = assign(expr ? evaluate(expr, row) : row[index], column, expr) }
            end
          else raise Error.new('0A000', "ALTER action #{action[:kind]} is not implemented")
          end
        end
      end
      validate_rows(t, t[:rows])
      @tables[t[:name]] = t
      @dirty = true
      Result.new
    end
  end
  Engine.prepend(SchemaChanges)
end
